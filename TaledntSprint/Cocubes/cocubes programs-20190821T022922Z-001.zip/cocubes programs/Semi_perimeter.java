import java.util.Scanner;

public class Semi_perimeter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
int c= sc.nextInt();
float sp=0;
sp=(a+b+c)/2;
System.out.println(sp);
	
	}

}
